
def test_collection():
    pass
