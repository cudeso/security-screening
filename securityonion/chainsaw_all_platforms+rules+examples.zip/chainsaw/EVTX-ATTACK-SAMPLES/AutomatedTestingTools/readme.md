This folder will host results of public automated EDR and MITRE ATTACK testing tools and scripts, which allow both to improve the 
panache_sysmon configuration and also to record different attack techniques.

To date tested frameworks:

1. Atomic RedTeam -> https://github.com/redcanaryco/atomic-red-team/tree/master/atomics
2. EDR TestingScript -> https://github.com/op7ic/EDR-Testing-Script
